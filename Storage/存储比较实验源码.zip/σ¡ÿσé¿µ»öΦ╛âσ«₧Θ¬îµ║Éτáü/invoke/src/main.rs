use candid::{CandidType, Decode, Encode};
use futures::future;
use ic_agent::agent::http_transport::ReqwestHttpReplicaV2Transport;
use ic_agent::Agent;
use ic_types::Principal;
use rayon::prelude::*;
use serde::Deserialize;
use std::arch::aarch64::float32x2_t;
use std::clone;
use std::fs::File;
use std::io::{Read, Write};
use std::sync::Arc;
use std::time::Duration;

#[derive(CandidType, Deserialize, Debug, Clone)]
struct Status {
    cycle_balance: u128,
    stable_memory: u128,
    wasm_memory: u128,
    time: u128,
    during: u128,
}

#[derive(CandidType, Deserialize, Debug, Clone)]
struct R {
    status: Status,
    exec: String,
}

#[tokio::main]
async fn main() {
    upload_nonstable().await;
    upload_stable().await;
}

async fn upload_nonstable() {
    let url = "https://ic0.app";
    let transport = ReqwestHttpReplicaV2Transport::create(url).unwrap();
    let agent = Agent::builder().with_transport(transport).build().unwrap();
    let stable_canister = Principal::from_text("q63io-vqaaa-aaaam-aabaa-cai").unwrap();
    let waiter = garcon::Delay::builder()
        .throttle(Duration::from_millis(20))
        .timeout(Duration::from_millis(200 * 20 * 300))
        .build();
    let mut start_status = Status {
        cycle_balance: 0,
        stable_memory: 0,
        wasm_memory: 0,
        time: 0,
        during: 0,
    };
    let mut end_status = Status {
        cycle_balance: 0,
        stable_memory: 0,
        wasm_memory: 0,
        time: 0,
        during: 0,
    };
    let mut store_time = 0;
    for i in 0..300 {
        println!("upload slice index : {}", i);
        let buffer = vec![0xFFu8; 1024 * 1024 * 1.5 as usize];
        let res = agent
            .update(&stable_canister, "upload")
            .with_arg(Encode!(&i.to_string(), &buffer).unwrap())
            .call_and_wait(waiter.clone())
            .await
            .unwrap();
        let r = Decode!(&res, R).unwrap();
        if i == 0 {
            start_status = r.status.clone()
        } else if i == 299 {
            end_status = r.status.clone()
        }
        store_time += r.status.during;
        println!("index  : {},  response status : {:?}", i, r);
    }
    println!("start status : {:?}", start_status);
    println!("end status : {:?}", end_status)
}

async fn upload_stable() {
    let url = "https://ic0.app";
    let transport = ReqwestHttpReplicaV2Transport::create(url).unwrap();
    let agent = Agent::builder().with_transport(transport).build().unwrap();
    let stable_canister = Principal::from_text("magsy-yyaaa-aaaap-aaaea-cai").unwrap();
    let waiter = garcon::Delay::builder()
        .throttle(Duration::from_millis(20))
        .timeout(Duration::from_millis(200 * 20 * 300))
        .build();
    let mut start_status = Status {
        cycle_balance: 0,
        stable_memory: 0,
        wasm_memory: 0,
        time: 0,
        during: 0,
    };
    let mut end_status = Status {
        cycle_balance: 0,
        stable_memory: 0,
        wasm_memory: 0,
        time: 0,
        during: 0,
    };
    let mut store_time = 0;
    for i in 0..300 {
        println!("upload slice index : {}", i);
        let buffer = vec![0xFFu8; 1024 * 1024 * 1.5 as usize];
        let res = agent
            .update(&stable_canister, "upload")
            .with_arg(Encode!(&i.to_string(), &buffer).unwrap())
            .call_and_wait(waiter.clone())
            .await
            .unwrap();
        let r = Decode!(&res, R).unwrap();
        if i == 0 {
            start_status = r.status.clone()
        } else if i == 299 {
            end_status = r.status.clone()
        }
        store_time += r.status.during;
        println!("index  : {},  response status : {:?}", i, r);
    }
    println!("start status : {:?}", start_status);
    println!("end status : {:?}", end_status)
}
